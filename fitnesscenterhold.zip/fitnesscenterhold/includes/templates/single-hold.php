<?php

/**
 * Dette er templaten for fitnescenterhold og tilhørende trænere
 *
 * Du kan selv lave din egen template ved at kopiere denne ind i dit tema
 *  - Opret en mappe med navnet: fitnesscenterhold
 *  - Kopier denne fil ind i mappen
 *  - Ret den til som du ønsker det
 *
 * @link       http://jaxweb.dk/
 * @since      1.0.0
 *
 * @package    fitnescenterhold
 * @subpackage fitnescenterhold/includes/templates
 */ 


get_header();

_e("Alt det der er ind i melllem :-) - Vis Hold");

get_footer();