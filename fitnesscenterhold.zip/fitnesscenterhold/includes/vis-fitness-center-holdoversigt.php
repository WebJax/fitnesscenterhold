<?php
/**
 * Vis oversigt over hold på en smart måde
 *
 * @link       http://jaxweb.dk/
 * @since      1.0.0
 *
 * @package    fitnescenterhold
 * @subpackage fitnescenterhold/includes/
 */ 
?>

<h1>
  Holdoversigt
</h1>



		<div class="holdoversigt">
        <?php
      $args = array(
          'post_type' => 'hold',
          'posts_per_page' => -1,
          'orderby' => 'post_title',
          'order' => 'ASC',        
        );
        $my_query = new WP_Query($args);
        if ($my_query->have_posts()) {
          while ($my_query->have_posts()) : $my_query->the_post();
            echo '<div class="hold"><a href="post.php?post='.get_the_ID().'&action=edit" class="holdlink"><div class="holdbilledecontainer"><img src="'.get_the_post_thumbnail_url().'" class="holdbilledet"></div><div class="holdtitel">'.esc_html( get_the_title() ).'</div></a></div>';
          endwhile;
        } ?>
        
    </div> <?php // slut ?>