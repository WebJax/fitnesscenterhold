<?php
/**
 * Dette er oprettelse af cpt til hold
 *
 * @link       http://jaxweb.dk/
 * @since      1.0.0
 *
 * @package    fitnescenterhold
 * @subpackage fitnescenterhold/includes/
 */ 




/*
|--------------------------------------------------------------------------
| DEFINE THE CUSTOM POST TYPE FOR TEAMS (HOLD)
|--------------------------------------------------------------------------
*/
 
/**
 * Setup Hold Custom Post Type
 *
 * @since 1.0
*/
 

    // Custom Post Type Labels
    $labels = array(
        'name' => esc_html__( 'Hold', 'rc_tc' ),
        'singular_name' => esc_html__( 'Hold', 'rc_tc' ),
        'add_new' => esc_html__( 'Tilføj Nyt', 'rc_tc' ),
        'add_new_item' => esc_html__( 'Tilføj Nyt Hold', 'rc_tc' ),
        'edit_item' => esc_html__( 'Editer Hold', 'rc_tc' ),
        'new_item' => esc_html__( 'Nyt Hold', 'rc_tc' ),
        'view_item' => esc_html__( 'Vis Hold', 'rc_tc' ),
        'search_items' => esc_html__( 'Søg efter Hold', 'rc_tc' ),
        'not_found' => esc_html__( 'Ingen hold fundet', 'rc_tc' ),
        'not_found_in_trash' => esc_html__( 'Ingen hold fundet i skraldespand', 'rc_tc' ),
        'parent_item_colon' => ''
    );
 
    // Supports
    $supports = array( 'title', 'editor', 'thumbnail', 'comments' );
 
    // Custom Post Type Supports
    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => 'hold', 'with_front' => true ),
        'capability_type' => 'oprethold',
        'hierarchical' => false,
        'show_in_menu' => 'edit.php?post_type=hold',
        'supports' => $supports,
    		'register_meta_box_cb' 	=> 'hold_meta_box',
        'menu_icon' => 'dashicons-groups', // you can set your own icon here
    );

register_post_type( 'hold' , $args );
add_action('save_post', 'save_hold_meta', 1, 2); // save the custom fields

function hold_meta_box() {
  add_meta_box("hold_oplysninger", "Hold oplysninger", "hold_meta_options", "hold", "side", "high" );
}

function hold_meta_options() {
  	global $post;
		// Noncename needed to verify where the data originated
		echo '<input type="hidden" name="traenermeta_noncename" id="traenermeta_noncename" value="' . 
		wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
    $selectedtrainer = get_post_meta($post->ID, 'traener_name', true);
		// Get the location data if its already been entered
		$mandag = get_post_meta($post->ID, 'mandag', true);	
		$tirsdag = get_post_meta($post->ID, 'tirsdag', true);	
		$onsdag = get_post_meta($post->ID, 'onsdag', true);	
		$torsdag = get_post_meta($post->ID, 'torsdag', true);	
		$fredag = get_post_meta($post->ID, 'fredag', true);	
		$lordag = get_post_meta($post->ID, 'lordag', true);	
		$sondag = get_post_meta($post->ID, 'sondag', true);	
		$holdstartmandag = get_post_meta($post->ID, 'holdstartmandag', true);
		$holdslutmandag = get_post_meta($post->ID, 'holdslutmandag', true);
		$holdstarttirsdag = get_post_meta($post->ID, 'holdstarttirsdag', true);
		$holdsluttirsdag = get_post_meta($post->ID, 'holdsluttirsdag', true);
		$holdstartonsdag = get_post_meta($post->ID, 'holdstartonsdag', true);
		$holdslutonsdag = get_post_meta($post->ID, 'holdslutonsdag', true);
		$holdstarttorsdag = get_post_meta($post->ID, 'holdstarttorsdag', true);
		$holdsluttorsdag = get_post_meta($post->ID, 'holdsluttorsdag', true);
		$holdstartfredag = get_post_meta($post->ID, 'holdstartfredag', true);
		$holdslutfredag = get_post_meta($post->ID, 'holdslutfredag', true);
		$holdstartlordag = get_post_meta($post->ID, 'holdstartlordag', true);
		$holdslutlordag = get_post_meta($post->ID, 'holdslutlordag', true);
		$holdstartsondag = get_post_meta($post->ID, 'holdstartsondag', true);
		$holdslutsondag = get_post_meta($post->ID, 'holdslutsondag', true);
		?>
		<table>
      <tr><td>
        <label for="traener_name">Trænernavn:</label>
        <br/><select name="traener_name" id="traener_name"/>
          
        <?php
        $args = array(
      	  'post_type' => 'traener',
					'posts_per_page' => -1,
					'orderby' => 'post_title', // meta_value',
					'order'   => 'ASC',
        );
        $my_query = new WP_Query($args);
				if ($my_query->have_posts()) {
					while ($my_query->have_posts()) : $my_query->the_post();
						if ($selectedtrainer == get_the_title()) {
							echo '<option value="'.esc_html( get_the_title() ).'" selected=selected>'.esc_html( get_the_title() ).'</option>'; 							
						} else {
							echo '<option value="'.esc_html( get_the_title() ).'">'.esc_html( get_the_title() ).'</option>'; 
						} ?>
        </select>
      </td></tr>
			<tr><td><input type="checkbox" value="mandag" name="mandag"<?php if($mandag=="mandag") { echo 'checked="checked"'; } ?>/>Mandag</td></tr>
			<tr>
				<td><input type="text" name="mandagholdstart" value="<?php echo $holdstartmandag;?>" size="5" maxlength="5"placeholder="18:00"><input type="text" name="mandagholdslut" value="<?php echo $holdslutmandag;?>" size="5" maxlength="5"placeholder="19:00"></td>
			</tr>
			<tr><td><input type="checkbox" value="tirsdag" name="tirsdag"<?php if($tirsdag=="tirsdag") { echo 'checked="checked"'; } ?>/>Tirsdag</td></tr>
			<tr>
				<td><input type="text" name="tirsdagholdstart" value="<?php echo $holdstarttirsdag;?>" size="5" maxlength="5"placeholder="18:00"><input type="text" name="tirsdagholdslut" value="<?php echo $holdsluttirsdag;?>" size="5" maxlength="5"placeholder="19:00"></td>
			</tr>
			<tr><td><input type="checkbox" value="onsdag" name="onsdag"<?php if($onsdag=="onsdag") { echo 'checked="checked"'; } ?>/>Onsdag</td></tr>
			<tr>
				<td><input type="text" name="onsdagholdstart" value="<?php echo $holdstartonsdag;?>" size="5" maxlength="5"placeholder="18:00"><input type="text" name="onsdagholdslut" value="<?php echo $holdslutonsdag;?>" size="5" maxlength="5"placeholder="19:00"></td>
			</tr>
			<tr><td><input type="checkbox" value="torsdag" name="torsdag"<?php if($torsdag=="torsdag") { echo 'checked="checked"'; } ?>/>Torsdag</td></tr>
			<tr>
				<td><input type="text" name="torsdagholdstart" value="<?php echo $holdstarttorsdag;?>" size="5" maxlength="5"placeholder="18:00"><input type="text" name="torsdagholdslut" value="<?php echo $holdsluttorsdag;?>" size="5" maxlength="5"placeholder="19:00"></td>
			</tr>
			<tr><td><input type="checkbox" value="fredag" name="fredag"<?php if($fredag=="fredag") { echo 'checked="checked"'; } ?>/>Fredag</td></tr>
			<tr>
				<td><input type="text" name="fredagholdstart" value="<?php echo $holdstartfredag;?>" size="5" maxlength="5"placeholder="18:00"><input type="text" name="fredagholdslut" value="<?php echo $holdslutfredag;?>" size="5" maxlength="5"placeholder="19:00"></td>
			</tr>
			<tr><td><input type="checkbox" value="lordag" name="lordag"<?php if($lordag=="lordag") { echo 'checked="checked"'; } ?>/>Lørdag</td></tr>
			<tr>
				<td><input type="text" name="lordagholdstart" value="<?php echo $holdstartlordag;?>" size="5" maxlength="5"placeholder="18:00"><input type="text" name="lordagholdslut" value="<?php echo $holdslutlordag;?>" size="5" maxlength="5"placeholder="19:00"></td>
			</tr>
			<tr><td><input type="checkbox" value="sondag" name="sondag"<?php if($sondag=="sondag") { echo 'checked="checked"'; } ?>/>Søndag</td></tr>
			<tr>
				<td><input type="text" name="sondagholdstart" value="<?php echo $holdstartsondag;?>" size="5" maxlength="5"placeholder="18:00"><input type="text" name="sondagholdslut" value="<?php echo $holdslutsondag;?>" size="5" maxlength="5"placeholder="19:00"></td>
			</tr>
    </table> <?php
		endwhile; 
	}
	wp_reset_query();
}

function save_hold_meta($post_id, $post) {
	
	// verify this came from the our screen and with proper authorization,
	// because save_post can be triggered at other times
	if ( isset($_POST['holdmeta_noncename']) && !wp_verify_nonce( $_POST['hold$meta_noncename'], plugin_basename(__FILE__) )) {
		return $post->ID;
	}
  
	// Is the user allowed to edit the post or page?
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;

	// OK, we're authenticated: we need to find and save the data
	// We'll put it into an array to make it easier to loop though.
	
	if (isset($_POST['traener_name'])) $events_meta['traener_name'] = $_POST['traener_name'];
	if (isset($_POST['mandag'])) $events_meta['mandag'] = $_POST['mandag'];
	if (isset($_POST['tirsdag'])) $events_meta['tirsdag'] = $_POST['tirsdag'];
	if (isset($_POST['onsdag'])) $events_meta['onsdag'] = $_POST['onsdag'];
	if (isset($_POST['torsdag'])) $events_meta['torsdag'] = $_POST['torsdag'];
	if (isset($_POST['fredag'])) $events_meta['fredag'] = $_POST['fredag'];
	if (isset($_POST['lordag'])) $events_meta['lordag'] = $_POST['lordag'];
	if (isset($_POST['sondag'])) $events_meta['sondag'] = $_POST['sondag'];
	if (isset($_POST['mandagholdstart'])) $events_meta['holdstartmandag'] = $_POST['mandagholdstart'];
	if (isset($_POST['mandagholdslut'])) $events_meta['holdslutmandag'] = $_POST['mandagholdslut'];
	if (isset($_POST['tirsdagholdstart'])) $events_meta['holdstarttirsdag'] = $_POST['tirsdagholdstart'];
	if (isset($_POST['tirsdagholdslut'])) $events_meta['holdsluttirsdag'] = $_POST['tirsdagholdslut'];
	if (isset($_POST['onsdagholdstart'])) $events_meta['holdstartonsdag'] = $_POST['onsdagholdstart'];
	if (isset($_POST['onsdagholdslut'])) $events_meta['holdslutonsdag'] = $_POST['onsdagholdslut'];
	if (isset($_POST['torsdagholdstart'])) $events_meta['holdstarttorsdag'] = $_POST['torsdagholdstart'];
	if (isset($_POST['torsdagholdslut'])) $events_meta['holdsluttorsdag'] = $_POST['torsdagholdslut'];
	if (isset($_POST['fredagholdstart'])) $events_meta['holdstartfredag'] = $_POST['fredagholdstart'];
	if (isset($_POST['fredagholdslut'])) $events_meta['holdslutfredag'] = $_POST['fredagholdslut'];
	if (isset($_POST['lordagholdstart'])) $events_meta['holdstartlordag'] = $_POST['lordagholdstart'];
	if (isset($_POST['lordagholdslut'])) $events_meta['holdslutlordag'] = $_POST['lordagholdslut'];
	if (isset($_POST['sondagholdstart'])) $events_meta['holdstartsondag'] = $_POST['sondagholdstart'];
	if (isset($_POST['sondagholdslut'])) $events_meta['holdslutsondag'] = $_POST['sondagholdslut'];

	// Add values of $events_meta as custom fields
	if (isset($events_meta)) {
		foreach ($events_meta as $key => $value) { // Cycle through the $events_meta array!
			if( $post->post_type == 'revision' ) return; // Don't store custom data twice
			$value = implode(',', (array)$value); // If $value is an array, make it a CSV (unlikely)
			if(get_post_meta($post->ID, $key, FALSE)) { // If the custom field already has a value
				update_post_meta($post->ID, $key, $value);
			} else { // If the custom field doesn't have a value
				add_post_meta($post->ID, $key, $value);
			}
			if(!$value) delete_post_meta($post->ID, $key); // Delete if blank
		}
	}
}


/*
|--------------------------------------------------------------------------
| DEFINE THE CUSTOM POST TYPE FOR TRAINERS (TRÆNERE)
|--------------------------------------------------------------------------
*/
 
/**
 * Setup Traener Custom Post Type
 *
 * @since 1.0
*/

/* Resetting variables */
$labels = array();
$supports = array();
$args = array();

    // Custom Post Type Labels
    $labels = array(
        'name' => esc_html__( 'Trænere', 'rc_tc' ),
        'singular_name' => esc_html__( 'Træner', 'rc_tc' ),
        'add_new' => esc_html__( 'Tilføj Ny', 'rc_tc' ),
        'add_new_item' => esc_html__( 'Tilføj Ny Træner', 'rc_tc' ),
        'edit_item' => esc_html__( 'Editer Træner', 'rc_tc' ),
        'new_item' => esc_html__( 'Ny Træner', 'rc_tc' ),
        'view_item' => esc_html__( 'Vis Træner', 'rc_tc' ),
        'search_items' => esc_html__( 'Søg efter Træner', 'rc_tc' ),
        'not_found' => esc_html__( 'Ingen træner fundet', 'rc_tc' ),
        'not_found_in_trash' => esc_html__( 'Ingen træner fundet i skraldespand', 'rc_tc' ),
        'parent_item_colon' => ''
    );
 
    // Supports
    $supports = array( 'title', 'editor', 'thumbnail' );
 
    // Custom Post Type Supports
    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => 'traener', 'with_front' => true ),
        'capability_type' => 'oprethold',
        'hierarchical' => false,
        'show_in_menu' => 'edit.php?post_type=traener',
        'supports' => $supports,
        'menu_icon' => 'dashicons-id', // you can set your own icon here
        'featured_image' => 'Profil billede',
        'set_featured_image' => 'Indstil profil billede',
        'remove_featured_image' => 'Fjern profil billede',
        'use_featured_image' => 'Brug som profil billede',
    );

register_post_type( 'traener' , $args );
