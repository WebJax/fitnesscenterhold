<?php

/*
Plugin Name: Fitnesscenter Hold
Plugin URL: http://jaxweb.dk/
Description: Holdbeskrivelser med tilhørende træner
Version: 0.1
Author: Jacob Thygesen
Author URI: http://jaxweb.dk/
*/

function fitnesscenterhold_pagetemplates( $page_template )
{
    if ( is_page( 'allehold' ) ) {
        $page_template = dirname( __FILE__ ) . 'includes/templates/allehold.php';
    }
    return $page_template;
}


function vis_fitness_hold() {
  require_once(dirname( __FILE__) . '/includes/vis-fitness-center-holdoversigt.php');
}

function custom_enter_trainer_name( $title ){
     $screen = get_current_screen();
     if  ( 'traener' == $screen->post_type ) {
          $title = 'Indtast træners fulde navn';
     }
     return $title;
}


function fitness_hold_menu() { 
  add_menu_page('Vis oversigt', 
                'Fitness Center Oversigt', 
                'manage_options', 
                'fitnesshold', 
                'vis_fitness_hold', 
                'dashicons-groups', 
                9);
  //add_submenu_page('fitnesshold', 'Hold', 'Hold', 'manage_options', 'edit.php?post_type=hold');
  add_submenu_page('fitnesshold', 'Hold', 'Tilføj Nyt Hold', 'publish_posts', 'post-new.php?post_type=hold');
  add_submenu_page('fitnesshold', 'Trænere', 'Trænere', 'publish_posts', 'edit.php?post_type=traener');
  add_submenu_page('fitnesshold', 'Træner', 'Tilføj Ny Træner', 'publish_posts', 'post-new.php?post_type=traener');  
}

function fc_registrer_cpt() {
  require_once (dirname( __FILE__ ) .'/includes/register-hold-post-type.php');
  require_once (dirname( __FILE__ ) .'/includes/register-single-cpts.php');
}

function load_fitnesshold_wp_admin_style($hook) {
  wp_enqueue_style( 'fitnesshold_wp_admin_css', plugins_url('/includes/css/admin-styles.css', __FILE__) );
}

function load_fitnesshold_style() {
  wp_enqueue_style( 'fitnesshold_css', plugins_url('/includes/css/fitnesscenterhold-styles.css', __FILE__) );
}


function cloningrolesforfitness()
{
    global $wp_roles;  // Delcaring roles and collecting the author role capability here.
    if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();

    $author = $wp_roles->get_role('editor');
    //Adding a 'new_role' with all editor caps
    $wp_roles->add_role('centerleder', 'Centerleder', $author->capabilities);
    
    $author = $wp_roles->get_role('author');
    //Adding a 'new_role' with all author caps
    $wp_roles->add_role('traener', 'Træner', $author->capabilities);

    $author = $wp_roles->get_role('subscriber');
    //Adding a 'new_role' with all subscriber caps
    $wp_roles->add_role('medlem', 'Medlem', $author->capabilities);
}


require_once (dirname( __FILE__ ) .'/includes/add-page-templates.php');
add_action( 'admin_enqueue_scripts', 'load_fitnesshold_wp_admin_style' );
add_action( 'wp_enqueue_scripts', 'load_fitnesshold_style' );
add_action( 'init', 'fc_registrer_cpt' );
add_action( 'admin_menu', 'fitness_hold_menu'); 
add_filter( 'enter_title_here','custom_enter_trainer_name');
add_filter( 'page_template', 'fitnesscenterhold_pagetemplates' );
add_action( 'init', 'cloningrolesforfitness');


function fc_install_plugin() {
    // trigger our function that registers the custom post type
    fc_registrer_cpt();
 
    // clear the permalinks after the post type has been registered
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'fc_install_plugin' );
